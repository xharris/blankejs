BlankE game engine uses the following:

- Love2D [ZLIB](https://love2d.org/wiki/License)
- bump.lua [MIT](https://github.com/kikito/bump.lua)
- bitop-lua [MIT](https://github.com/AlberTajuelo/bitop-lua)
- lua-clasp [MIT](https://github.com/evolbug/lua-clasp)
- json.lua [MIT](https://github.com/rxi/json.lua)
- NoobHub [WTFPL](https://github.com/Overtorment/NoobHub)
- [itraykov/profile.lua](https://bitbucket.org/itraykov/profile.lua)
- Tieske uuid [Apache 2.0](https://github.com/Tieske/uuid)
