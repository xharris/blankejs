```
require('blanke.Blanke')

function BlankE.load([args], [unfilteredArgs])
    BlankE.options = {
        -- some options
    }
end
```