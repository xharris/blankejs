## Other libraries used in blanke

[HardonCollider](https://love2d.org/wiki/HC) collision detection