npm install

(if there are problems running 'nw .') npm install nw --nw_build_type=sdk


git submodule init

git submodule update
