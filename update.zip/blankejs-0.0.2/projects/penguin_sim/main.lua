-- engine
BlankE = require('blanke.Blanke')

function love.load()
	
end