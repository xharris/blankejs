BlankE.addState("MainMenu")

function MainMenu:enter()
	
end

function MainMenu:draw()
	
end