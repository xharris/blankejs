BlankE.addEntity("Player");

function Player:init()
	self.gold = 0
end

function Player:update(dt)

end

function Player:damage(x) end