-- engine
BlankE = require('blanke.Blanke')
ProFi = blanke_require('plugins.ProFi')
ProFi:start()

function BlankE.load()
	BlankE.options = {
		state="PathfindState",
		plugins={"Pathfinder"},
		resolution=2,
		--filter="nearest",
		debug={
			log=true
		},
		inputs={
			{"lclick","mouse.1"},
			{"rclick","mouse.2"},
			{"move_l","left","a"},
			{"move_r","right","d"},
			{"move_u","up","w"},
			{"move_d","down","s"}
		}
	}
	
	Draw.setBackgroundColor("white")
end