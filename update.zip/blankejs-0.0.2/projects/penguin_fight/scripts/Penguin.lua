BlankE.addEntity("Penguin");

function Penguin:init()

end

function Penguin:update(dt)

end

function Penguin:draw()

end
