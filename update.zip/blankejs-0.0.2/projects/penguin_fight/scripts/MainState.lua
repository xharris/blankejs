BlankE.addState("PlayState");

function PlayState:enter()

end

function PlayState:update(dt)

end

function PlayState:draw()

end
