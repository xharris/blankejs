-- engine
BlankE = require('blanke.Blanke')

function love.load()
	BlankE.init("PlayState")
end